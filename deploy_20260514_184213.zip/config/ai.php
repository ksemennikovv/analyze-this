<?php
/* ================================================================
 * NirvaBody — AI Model Configuration
 * ACTIVE_PROVIDER: 'claude' | 'openai' | 'deepseek'
 * ================================================================ */

define('ACTIVE_PROVIDER', 'deepseek');

/* ---------- Claude (Anthropic) ---------------------------------- */
define('CLAUDE_API_KEY', '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');
define('CLAUDE_MODEL',   'claude-sonnet-4-6');

/* ---------- OpenAI ---------------------------------------------- */
define('OPENAI_API_KEY', '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');
define('OPENAI_MODEL',   'gpt-4o-mini');

/* ---------- DeepSeek -------------------------------------------- */
define('DEEPSEEK_API_KEY', 'sk-322aa481d0d6497bb10e284f1c3a9379');
define('DEEPSEEK_MODEL',   'deepseek-chat');
