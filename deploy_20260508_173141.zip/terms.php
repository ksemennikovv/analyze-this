<?php
require_once __DIR__ . '/config/app.php';
$pageTitle = 'Условия использования — NirvaBody';
$pageCss   = [];
$pageJs    = [];
require __DIR__ . '/includes/head.php';
?>
<div class="phone"><div class="page">
<?php require __DIR__ . '/includes/header.php'; ?>
<?php require __DIR__ . '/pages/terms.php'; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
<?php require __DIR__ . '/includes/scripts.php'; ?>
