<?php
error_reporting(0);
ini_set('display_errors', 0);
session_start();

if (ob_get_level()) ob_end_clean();
ini_set('output_buffering', 'off');
ini_set('zlib.output_compression', false);

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');

require_once __DIR__ . '/config.php';

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['messages'])) {
    echo "data: [DONE]\n\n";
    exit;
}

$system = trim(file_get_contents(__DIR__ . '/../prompt.txt'));

$messages = [];
foreach ($input['messages'] as $m) {
    if (isset($m['role'], $m['content']) && in_array($m['role'], ['user', 'assistant'], true)) {
        $messages[] = ['role' => $m['role'], 'content' => (string)$m['content']];
    }
}

if (empty($messages)) {
    echo "data: [DONE]\n\n";
    exit;
}

/* ================================================================
 * Claude (Anthropic) — pass-through SSE
 * ================================================================ */
if (ACTIVE_PROVIDER === 'claude') {

    $payload = json_encode([
        'model'      => CLAUDE_MODEL,
        'max_tokens' => 3000,
        'system'     => $system,
        'messages'   => $messages,
        'stream'     => true,
    ]);

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: '          . CLAUDE_API_KEY,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_WRITEFUNCTION  => function ($ch, $data) {
            echo $data;
            if (ob_get_level()) ob_flush();
            flush();
            return strlen($data);
        },
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_TIMEOUT        => 120,
    ]);

    curl_exec($ch);
    curl_close($ch);
    exit;
}

/* ================================================================
 * OpenAI / DeepSeek (OpenAI-compatible API)
 * Uses non-streaming mode — more reliable on shared/proxied hosting.
 * Response is normalised to Claude SSE format so the JS parser
 * works without changes.
 * ================================================================ */
if (ACTIVE_PROVIDER === 'openai' || ACTIVE_PROVIDER === 'deepseek') {

    $url    = ACTIVE_PROVIDER === 'openai'
        ? 'https://api.openai.com/v1/chat/completions'
        : 'https://api.deepseek.com/v1/chat/completions';
    $apiKey = ACTIVE_PROVIDER === 'openai' ? OPENAI_API_KEY  : DEEPSEEK_API_KEY;
    $model  = ACTIVE_PROVIDER === 'openai' ? OPENAI_MODEL    : DEEPSEEK_MODEL;

    $oaiMessages = array_merge(
        [['role' => 'system', 'content' => $system]],
        $messages
    );

    $payload = json_encode([
        'model'      => $model,
        'messages'   => $oaiMessages,
        'stream'     => false,
        'max_tokens' => 3000,
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
    ]);

    $body     = curl_exec($ch);
    $curlErr  = curl_errno($ch) ? curl_error($ch) : null;
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr) {
        echo 'data: ' . json_encode([
            'type'  => 'error',
            'error' => ['message' => 'cURL: ' . $curlErr],
        ]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

    $json = $body ? json_decode($body, true) : null;

    if (!$json) {
        $preview = $body ? substr($body, 0, 300) : '';
        $msg     = $preview !== '' ? "HTTP $httpCode: $preview" : "Пустой ответ (HTTP $httpCode)";
        echo 'data: ' . json_encode(['type' => 'error', 'error' => ['message' => $msg]]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

    if (isset($json['error'])) {
        $msg = $json['error']['message'] ?? 'API error';
        echo 'data: ' . json_encode(['type' => 'error', 'error' => ['message' => $msg]]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

    $text = $json['choices'][0]['message']['content'] ?? null;

    if ($text === null || $text === '') {
        echo 'data: ' . json_encode([
            'type'  => 'error',
            'error' => ['message' => 'Пустой ответ от модели (HTTP ' . $httpCode . ')'],
        ]) . "\n\n";
        if (ob_get_level()) ob_flush();
        flush();
        exit;
    }

    echo 'data: ' . json_encode([
        'type'  => 'content_block_delta',
        'delta' => ['type' => 'text_delta', 'text' => $text],
    ]) . "\n\n";
    if (ob_get_level()) ob_flush();
    flush();

    echo "data: [DONE]\n\n";
    if (ob_get_level()) ob_flush();
    flush();

    exit;
}

/* unknown provider */
echo 'data: ' . json_encode([
    'type'  => 'error',
    'error' => ['message' => 'Неизвестный провайдер: ' . ACTIVE_PROVIDER],
]) . "\n\n";
