<?php
if (ob_get_level()) ob_end_clean();
ini_set('output_buffering', 'off');
ini_set('zlib.output_compression', false);

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');

define('CLAUDE_API_KEY', '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');
define('CLAUDE_MODEL', 'claude-sonnet-4-6');

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['messages'])) {
    echo "data: [DONE]\n\n";
    exit;
}

$system = trim(file_get_contents(__DIR__ . '/../prompt.txt'));

$messages = [];
foreach ($input['messages'] as $m) {
    if (isset($m['role'], $m['content']) && in_array($m['role'], ['user', 'assistant'], true)) {
        $messages[] = ['role' => $m['role'], 'content' => (string)$m['content']];
    }
}

if (empty($messages)) {
    echo "data: [DONE]\n\n";
    exit;
}

$payload = json_encode([
    'model'      => CLAUDE_MODEL,
    'max_tokens' => 1024,
    'system'     => $system,
    'messages'   => $messages,
    'stream'     => true,
]);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST          => true,
    CURLOPT_POSTFIELDS    => $payload,
    CURLOPT_HTTPHEADER    => [
        'Content-Type: application/json',
        'x-api-key: ' . CLAUDE_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_WRITEFUNCTION => function ($ch, $data) {
        echo $data;
        if (ob_get_level()) ob_flush();
        flush();
        return strlen($data);
    },
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_TIMEOUT        => 120,
]);

curl_exec($ch);
curl_close($ch);
