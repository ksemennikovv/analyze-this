<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u94574gq_analyze');
define('DB_USER', 'u94574gq_analyze');
define('DB_PASS', 'qFegPo@DfPl42026');

function db() {
    static $conn = null;
    if ($conn === null) {
        mysqli_report(MYSQLI_REPORT_OFF);
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($conn->connect_error) {
                http_response_code(500);
                die(json_encode(['ok' => false, 'error' => 'Ошибка сервера. Попробуйте позже.']));
            }
            $conn->set_charset('utf8mb4');
        } catch (Exception $e) {
            http_response_code(500);
            die(json_encode(['ok' => false, 'error' => 'Ошибка сервера. Попробуйте позже.']));
        }
    }
    return $conn;
}
