<?php
/* ================================================================
 * NirvaBody — AI Model Configuration
 * ================================================================
 * ACTIVE_PROVIDER: 'claude' | 'openai' | 'deepseek'
 * Укажите провайдера и вставьте API-ключ нужного сервиса.
 * Цены указаны за 1 млн токенов (вход / выход), приблизительно.
 * ================================================================ */

define('ACTIVE_PROVIDER', 'deepseek');

/* ---------- Claude (Anthropic) ---------------------------------- */
define('CLAUDE_API_KEY', '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');          /* вставьте ключ sk-ant-... */
define('CLAUDE_MODEL',   'claude-sonnet-4-6');
/*
 Модели Claude по возрастанию стоимости:
   'claude-haiku-4-5-20251001'  — $0.80 / $4.00    самый дешёвый, быстрый
   'claude-sonnet-4-6'          — $3.00 / $15.00   баланс качества и цены  ← default
   'claude-opus-4-7'            — $15.00 / $75.00  максимальное качество
*/

/* ---------- OpenAI ---------------------------------------------- */
define('OPENAI_API_KEY', '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');          /* вставьте ключ sk-...       */
define('OPENAI_MODEL',   'gpt-4o-mini');
/*
 Модели OpenAI по возрастанию стоимости:
   'gpt-4.1-nano'               — $0.10 / $0.40    минимальная стоимость
   'gpt-4o-mini'                — $0.15 / $0.60    дешёвый и быстрый       ← default
   'gpt-4.1-mini'               — $0.40 / $1.60    чуть мощнее mini
   'o4-mini'                    — $1.10 / $4.40    reasoning-модель
   'gpt-4.1'                    — $2.00 / $8.00    мощная основная модель
   'gpt-4o'                     — $2.50 / $10.00   флагман GPT-4o
   'o3'                         — $10.00 / $40.00  топовая reasoning-модель
*/

/* ---------- DeepSeek -------------------------------------------- */
define('DEEPSEEK_API_KEY', 'sk-322aa481d0d6497bb10e284f1c3a9379');        /* вставьте ключ sk-...       */
define('DEEPSEEK_MODEL',   'deepseek-chat');
/*
 Модели DeepSeek по возрастанию стоимости:
   'deepseek-chat'              — $0.07 / $1.10    основная модель (V3)     ← default
   'deepseek-reasoner'          — $0.55 / $2.19    с цепочкой рассуждений (R1)
*/
